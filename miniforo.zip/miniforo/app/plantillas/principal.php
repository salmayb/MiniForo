<!DOCTYPE html>
<head>
<meta charset="UTF-8">
<link href="web/default.css" rel="stylesheet" type="text/css" />
<title>MINIFORO</title>
</head>
<body>
<div id="container" style="width: 450px;">
<div id="header">
<img src="web/logo.png" alt="mini foro logo" width="100px" height="100px">
<h1>MINIFORO versión 1.0</h1>
</div>

<div id="content">
   <?=$contenido_php ?>
</div>
</div>
</body>
</html>