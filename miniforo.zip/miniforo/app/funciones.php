<?php
//Verifica el si el usuario y la contraseña son válidos
function usuarioOk($usuario, $contraseña):bool {
   
   return strlen($usuario)>= 8 && $contraseña === strrev($usuario);

}

//busca la letra más repetida 
function wordsRepeated($cadena)
{
    // Convierte la cadena en un array de caracteres
    $caracteres = str_split($cadena); //pasa la cadena a un array con cada uno de los carácteres
    $conteo = array_count_values($caracteres); //cuanta las repeticiones de cada carácter
    
    arsort($conteo); // Ordena el array de manera descendente en base al número de repeticiones
    $maxChar = key($conteo); // Toma la primera clave del array ordenado (el que se repite más veces)
    
    // Detectar si es espacio en blanco
    return ($maxChar == ' ') ? "espacio en blanco" : $maxChar;
}

//Devuelve la palabra más repetida
function palabrasRepetidas($cadena) {
   $cadena = strtolower(trim($cadena)); // Convertir a minúsculas
   $resultado = ""; //almacenara la palabra más repetida
   $contador = -1;

   $arrayCadena = explode(" ", $cadena); //convertimos la cadena en un array de palabras
   foreach (array_count_values($arrayCadena) as $c => $v) { //contamos cuantas veces aparece cada palabra
       if ($v > $contador) { //si la nueva palabra tiene más repeticiones que la anterior, actualizamos $resultado
           $resultado = $c;
           $contador = $v;
       }
   }
   //devuelve la palabra más repetida
   return $resultado;
}
